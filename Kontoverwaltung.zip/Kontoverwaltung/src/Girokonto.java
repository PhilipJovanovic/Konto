
public class Girokonto extends Konto {
	private double limit;
	
	public Girokonto(double erstbetrag, double limit) {
		super(erstbetrag);
		this.limit = limit;
	}
	public boolean auszahlung(double betrag) {
		if((kontostand.get(kontostand.size()-1)+limit) >= betrag) {
			kontostand.add(kontostand.get(kontostand.size()-1)-betrag);
			return true;
		}
		System.out.println("Nicht genügend Geld vorhanden");
		return false;
	}
	public boolean überweisung(double betrag, Konto nKonto) {
		if((kontostand.get(kontostand.size()-1)+limit) >= betrag) {
			kontostand.add(kontostand.get(kontostand.size()-1)-betrag);
			nKonto.kontostand.add(kontostand.get(kontostand.size()-1)+betrag);
			return true;
		}
		System.out.println("Nicht genügend Geld vorhanden");
		return false;
	}
}
