import java.util.*;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Double> test = new ArrayList<Double>();
		test.add(123D);
		System.out.println(test.get(test.size()-1));
		Girokonto GK = new Girokonto(100,50);
		Girokonto GK2 = new Girokonto(250,100);
		Datum d = new Datum(11,9,2017);
		Sparkonto SP = new Sparkonto(d,1000);
		System.out.println(GK2);
		System.out.println(GK);
		System.out.println();
		GK2.einzahlen(100);
		
		System.out.println(GK2);
		System.out.println(GK);
		System.out.println();
		GK2.auszahlung(370);
		
		System.out.println(GK2);
		System.out.println(GK);
		System.out.println();
		GK2.auszahlung(10);
		
		System.out.println(GK2);
		System.out.println(GK);
		GK2.auszahlung(80);
		System.out.println();
		
		System.out.println(GK2);
		System.out.println(GK);
		System.out.println();
		
		GK2.überweisung(40, GK);
		System.out.println(GK2);
		System.out.println(GK);
		System.out.println();
		
	}
}
