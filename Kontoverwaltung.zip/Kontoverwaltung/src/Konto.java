import java.util.ArrayList;

public class Konto {
	//Klassenattribute
	private static double habenzins = 0.025;
	private static int kontonr_vergeben = 0;
	private static double zins = 0.04;
	
	//Konto Attribute
	private int kontonr;
	protected ArrayList<Double> kontostand = new ArrayList<Double>();
	
	public Konto(double erstbetrag) {
		kontonr = kontonr_vergeben++;
		kontostand.add(erstbetrag);
	}
	public void einzahlen(double betrag){
		kontostand.add(kontostand.get(kontostand.size()-1)+betrag);
	}
	public String toString() {
		return "Das Konto mit der Kontonummer: " + kontonr + " hat einen Kontostand von " + 
	kontostand + "€";
	}
}
