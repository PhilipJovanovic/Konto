
public class Sparkonto extends Konto {
	public Sparkonto(Datum d, double erstbetrag) {
		super(erstbetrag);
	}
	public boolean auszahlen(double betrag) {
		if((kontostand.get(kontostand.size())) >= betrag) {
			kontostand.add(kontostand.get(kontostand.size())-betrag);
			return true;
		}else {
			return false;
		}
	}
}
